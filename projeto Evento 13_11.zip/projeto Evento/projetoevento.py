from funcoes import *
usuarios = [['kevin','kevin@gmail','123']]
eventos = [['ANIMACZ','Um evento de anime que ocorre na cidade de Cajazeiras/PB, que reune varias atrações e competições de jogos e de cosplay. ','21/11/2024', 'Cajazeiras/PB', 25, 'kevin@gmail','mario','maria'],['COMIC CON','A Comic Con Experience - CCXP , o maior evento para os amantes de quadrinhos, séries, filmes, literatura, games dentre outros âmbitos da cultura geek. A Comic Con Experience é uma convenção brasileira de entretenimento e quadrinhos de vários gêneros .', '05/12/2024', 'São paulo/SP', 100, 'kevin@gmail'],['Jogatina XYZ', 'Um evento para jogadores de fifa se reúnirem e jogarem x1 para descubrirem quem é o melhor, o campeão ganhará um premio lendario digno de um proplayer.', '06/01/2025', 'Sousa/PB', 15, 'kevin@gmail']]

op = -1
while(op != 0):
    print('\033[0;32m===================== EVENTIN =======================\033[m\n')

    print('1-Cadastrar usuário')
    print('2-Login')
    print('0-Sair do programa\n')
    op = int(input('Digite a opção desejada: '))
    if(op == 1):
        nome = input('Digite seu nome: ')
        email = input('digite seu e-mail: ')
        senha = input('digite sua senha: ')
        senha2 = input('Repita sua senha: ')
        while(verificar_user_existente(email, usuarios)):
            email = input('digite novamente seu e-mail')
        while(not verificar_senha(senha, senha2)):
            print('dessa vez digite senhas iguais')
            senha = input('digite sua senha')
            senha2 = input('Repita sua senha')
        usuarios.append([nome, email, senha])
    elif(op == 2):
        validação1 = input('digite seu email: ')
        validação2 = input('digite sua senha: ')
        if(verificar_user_existente (validação1, usuarios) and verificar_senha_correta (validação2, usuarios)):
            opcao = -1
            print('\033[0;32mLogin feito com sucesso.\033[m\n')
            while(opcao != 8):
                print('1. Cadastrar novos eventos')
                print('2. Buscar eventos')
                print('3. Lista de eventos')
                print('4. Remover evento')
                print('5. Fazer inscrição em eventos')
                print('6. Lista de participantes e valor arrecardado do seu evento')
                print('7. Exibir ticke de suas inscrições em eventos')
                print('8. Voltar ao início\n')
                opcao = int(input('digite a opção desejada: '))
                if(opcao == 1):
                    events = input('Digite o titulo do seu evento: ')
                    sinopse = input('Fale qual o intuito do seu evento: ')
                    data = input('Digite a data do seu evento: ')
                    local = input('Digite o local do seu evento: ')
                    valor = int(input('Digite o valor de inscrição do seu evento: '))
                    lista = [events, sinopse, data, local, valor, validação1]
                    eventos.append(lista)
                    print('\033[0;32mEvento inscrito com sucesso\033[m\n')
                elif(opcao == 2):
                    buscaev = input('Digite o nome do evento: ')
                    buscar_evento(buscaev, eventos)
                elif(opcao == 3):
                   for i in eventos:
                    print(i[0],"\n")
                    print(f'Descrição do evento: {i[1]}\n')
                    print(f'Data do evento: {i[2]}.\n')
                    print(f'Local do evento: {i[3]}.\n')
                    print(f'Valor da inscrição: R${i[4]}.\n')
                   voltar = input('Digite qualquer coisa para voltar ao início: ')
                elif(opcao == 4):
                    exclusao = input('Digite o nome do evento que você deseja excluir: ')
                    contador = 0
                    for i in eventos:
                        if(i[5] == validação1 and i[0] == exclusao):
                            contador += 1
                            exclusao2 = input("Digite seu email para confirmar exclusão do evento: ")
                            if(exclusao2 == validação1):
                                eventos.remove(i)
                                print('\033[0;32mEvento removido com sucesso\033[m\n')
                            else:
                                print('\033[0;31mEmail invalido.\033[m\n')
                    if(contador <= 0):    
                        print('\033[0;31mVocê não possue nenhum evento com esse nome\033[m\n')
                elif(opcao == 5):
                    contador = 0
                    inscricao = input('Digite o nome do evento que você deseja participar: ')
                    for i in eventos:
                        if(i[0] == inscricao):
                            contador += 1
                            print(f'O valor da inscrição nesse evento é R$ {i[4]}.\n')
                            confirma = input('Digite seu email para confirmar a inscrição: ')
                            if(confirma == validação1 and i[5] != confirma):
                                nome = retorna_nomes(confirma, usuarios)
                                i.append(nome)
                                print('\033[0;32mInscrição realizada com sucesso\033[m\n')
                            else:
                                print('\033[0;31mEmail invalido.\033[m\n')    
                    if(contador == 0):
                        print('\033[0;31mEsse evento não existe\033[m\n')
                elif(opcao == 6):
                    verificar = input('Digite seu email para ver os participantes do seu evento(S): ')
                    for i in eventos:
                        if(i[5] == verificar):
                            print(f'{i[0]}')
                            print('Estes são os participantes do seu evento: ')
                            contador = 0
                            for participantes in range (6,len(i)):
                                contador += 1
                                print(f'\033[0;32m{i[participantes]}\033[m\n')
                            print(f'O valor arrecardado do seu evento é :R${contador * i[4]}')        
                elif(opcao == 7):
                    nomeUs = retorna_nomes(validação1, usuarios)
                    contador = 0
                    for i in eventos:
                        contador += 1
                        if(nomeUs in i):                    
                            print('\033[0;32m-------------------------------------------  EVENTIN  ------------------------------------\033[m\n')
                            print('\nEvento : ', i[0],'                ========== Ticket de compra ========       cliente :',nomeUs)
                            print('Data de realização do evento : ',i[2], '                                        Local do evento:', i[3] )
                            print(                            "Valor da inscrição :", i[4],"R$"                         )
                            print('\033[0;32m--------------------------------------Desejamos um ótimo evento!-------------------------------\033[m\n') 
                    if(contador <= 0):
                        print('\033[0;31mVocê não esta inscrito em nenhum evento.\033[m\n')                                                                                                                             
        else:
            print('\033[0;31mEmail ou senha incorreto.\033[m\n')    